import React from "react";

function PageNotFound(props) {
  return (
    <div className="pnf my-5 py-5">
      <h1>404 | Page not found</h1>
    </div>
  );
}

export default PageNotFound;
